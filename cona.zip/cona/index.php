<?php
include('login.php'); // Memasuk-kan skrip Login 

if(isset($_SESSION['login_user'])){
header("location: profile.php");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Website</title>
	
	<!-- Skrip CSS -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="lib/bootstrap.min.css">
<script src="lib/jquery.min.js"></script>
<script src="lib/bootstrap.min.js"></script>
   <link rel="stylesheet" href="style.css">
  </head>	
  <body>
	<div class="container">
		<div class="header">	
		<div class="row">
		<div class="col-sm-6">
			<h2>Logo</h2>
			<p>Silahkan Login Dahulu</p>
		</div>
		<div class="col-sm-6">
		<form action="" method="post">
			<label>Username :</label>
			<input id="name" name="username" placeholder="username" type="text">
			
			<label>Password :</label>
			<input id="password" name="password" placeholder="**********" type="password">
			
			<input type="submit" name="submit" id="submit" value="Login">	
		</form>
		</div>
		</div>
		</div>
   </div>

  </body>
</html>






