<?php
include('session.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Profile</title>
<link href="style.css" rel="stylesheet" type="text/css">
<style>
ul{
list-style-type: none;
margin: 0;
padding:0;
width: 300px;
background-color: #f1f1f1;
}

li a{
display: block;
color: #000;
padding: 8px 16px;
text-decoration: none;
}

li a.active{
background-color: #4CAF50;
color: white;
}

li a:hover{
background-color: #555;
color: white;
}

.isi{
background: rgba(0,0,0,.5);
color: blue;
padding:6%;
width:88%;
}

</style>
</head>
<body>
<div id="profile">
<b id="welcome">Selamat Datang : <i><?php echo $login_session; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>
<div class="isi">
<ul>
<li><a class="active" href="tambahkaryawan.php">Tambah Karyawan</a></li>
<li><a href="manager.php">Manager</a></li>
<li><a href="direktur.php">Direktur</a></li>
<li><a href="staf.php">Staf</a></li>
</ul>
</div>
</body>
</html>