<?php
include('session.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Karyawan</title>
	
	<!-- Skrip CSS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="lib/bootstrap.min.css">
	<script src="lib/jquery.min.js"></script>
	<script src="lib/bootstrap.min.js"></script>
	<link rel="stylesheet" href="style.css" type="text/css"/>
<style>
.isi{
background: rgba(0,0,0,.5);
color: blue;
padding:6%;
width:100%;
height:400px;
}
</style>
</head>	
<body>
<div id="profile">
<b id="welcome">Selamat Datang : <i><?php echo $login_session; ?></i></b>
<b id="logout"><a href="logout.php">Log Out</a></b>
</div>
<div class="isi">
	<form method="POST">
		<h2>Tambahkan Karyawan</h2>
		<label>Password Karyawan: </label>
		<input id="pass_karyawan"  type="password" name="pass_karyawan" placeholder="pass_karyawan"/><br>
		<label>User Karyawan: </label>
		<input id="user_karyawan"  type="text" name="user_karyawan" placeholder="user_karyawan"/><br>
		<label>Nama Karyawan: </label>
		<input id="nama_karyawan"  type="text" name="nama_karyawan" placeholder="nama_karyawan"/><br>
		<label>Alm Karyawan: </label>
		<input id="alm_karyawan"  type="text" name="alm_karyawan" placeholder="alm_karyawan"/><br>
		<label>Gaji Karyawan: </label>
		<input id="gaji_karyawan" type="text" name="gaji_karyawan" placeholder="gaji"/><br>
		<label>Tanggal Bergabung: </label>
		<input id="tgl_gabung" type="date" name="tgl_gabung"/><br>
        <input type="submit" name="input" id="input" value="Input">
	</form>
</div>
<?php
// Membangun Koneksi dengan Server dengan nama server, user_id dan password sebagai parameter
$connection = mysql_connect("localhost", "root", "");
// Seleksi Database
$db = mysql_select_db("cona", $connection);
if(isset($_POST['input'])){ // jika tombol 'BtnAdd' di klik, lakukan proses:
// ambil judul, isi berita, url
$pass_karyawan = $_POST['pass_karyawan'];
$user_karyawan = $_POST['user_karyawan'];
$nama_karyawan = $_POST['nama_karyawan'];
$alm_karyawan = $_POST['alm_karyawan'];
$gaji_karyawan = $_POST['gaji_karyawan'];
$tgl_gabung = $_POST['tgl_gabung'];

		$query = "INSERT INTO karyawan VALUES ('','$pass_karyawan','$user_karyawan','$nama_karyawan','$alm_karyawan','$gaji_karyawan','$tgl_gabung')"; 
		mysql_query($query) or die(mysql_error()."<br><br><a href=javascript:history.go(-1)><< back <<</a>");
		if ($query) {
			# code...
			echo "Simpan berita berhasil.";
		}
}
?>
</body>
</html>